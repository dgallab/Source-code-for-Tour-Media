#Daniel Gallab
#CPSC 326-02
#Assignment 5
#infers types, looks for type incompatibility,
#used before defined errors, etc


import mypl_ast as ast
import mypl_symbol_table as symbol_table
import error


class TypeChecker(ast.Visitor):
    
    def __init__(self):
        self.sym_table = symbol_table.SymbolTable()
        self.current_type = None
       
        

# visitor functions
    def visit_stmt_list(self, stmt_list):
         #every new statement list resets the type to none
        self.current_type = None;
        self.sym_table.push_environment()#makes comparisons easier- None is treated as compatible
        for stmt in stmt_list.stmts:#with any type
            stmt.accept(self)
        self.sym_table.pop_environment()
        
           
    def visit_simple_bool_expr(self, simple_bool_expr): #very easy to check-no comparison is needed with previous or next types
         simple_bool_expr.expr.accept(self)
         if type(simple_bool_expr.expr) == ast.SimpleExpr: # must look into other nodes to determine type of the expression
            term = simple_bool_expr.expr.term
         if type(simple_bool_expr.expr) == ast.ReadExpr: 
            if simple_bool_expr.expr.read_expr.is_read_int:
                 self.current_type = 'INT';
            else:
                 self.current_type = 'STRING';
         if type(simple_bool_expr.expr) == ast.IndexExpr:
            term = simple_bool_expr.expr.identifier
            x = self.sym_table.get_variable_type(term.lexeme)
            x = x[1:len(x)-1]
            self.current_type = x
         elif term.tokentype == 'ID': #tokentype ID and bool must be converted to actual type
            self.current_type = self.sym_table.get_variable_type(term.lexeme)
         elif term.tokentype == 'TRUE' or term.tokentype == 'FALSE': 
            self.current_type='BOOL'
         if self.current_type != 'BOOL': #if the inferred type is not a bool, then it is an error
            raise error.Error('expecting BOOL found ' + self.current_type+' ',term.line,term.column)
            
    def visit_complex_bool_expr(self, complex_bool_expr):
        complex_bool_expr.first_expr.accept(self) #bool or string or any type of list must use either == or !=
        x=self.current_type
        if self.current_type == 'BOOL' or self.current_type == 'STRING' : 
            if not(complex_bool_expr.bool_rel.tokentype == 'NOT_EQUAL' or complex_bool_expr.bool_rel.tokentype == 'EQUAL'):
                l = complex_bool_expr.bool_rel.line;
                c = complex_bool_expr.bool_rel.column;
                raise error.Error('invalid operand with '+ self.current_type+' ',l,c)     
        complex_bool_expr.second_expr.accept(self)
        if not(x == self.current_type or x == None):
           if not(self.current_type[0] == '[' and x=='[]'):#all this is added to make sure an empty list 
                if not(self.current_type == '[]' and x[0]=='['):  #is added to another list
                    raise error.Error('expecting '+x+' found ' + self.current_type+' ',complex_bool_expr.bool_rel.line,complex_bool_expr.bool_rel.column)#added to a list
        if complex_bool_expr.has_bool_connector:
            self.current_type = None; #reset types since different types can be allowed now
            complex_bool_expr.rest.accept(self)
              
    def visit_if_stmt(self, if_stmt): #will define a new environment
        if_stmt.if_part.bool_expr.accept(self)
        if_stmt.if_part.stmt_list.accept(self)
        for elseif in if_stmt.elseifs:
            elseif.bool_expr.accept(self)
            elseif.stmt_list.accept(self)
        if if_stmt.has_else:
            if_stmt.else_stmts.accept(self)
            
        
    def visit_while_stmt(self, while_stmt): #will define a new environment
         while_stmt.bool_expr.accept(self)
         while_stmt.stmt_list.accept(self)
       
    def visit_print_stmt(self, print_stmt):
        print_stmt.expr.accept(self)
        self.current_type = None;
        
       
    def visit_assign_stmt(self, assign_stmt):#only way to add new variable
        if not self.sym_table.variable_exists(assign_stmt.lhs.lexeme):
            self.sym_table.add_variable(assign_stmt.lhs.lexeme)
        assign_stmt.rhs.accept(self)
        if self.sym_table.get_variable_type(assign_stmt.lhs.lexeme)== '[]' or self.sym_table.get_variable_type(assign_stmt.lhs.lexeme)==None:
            self.sym_table.set_variable_type(assign_stmt.lhs.lexeme,self.current_type)     
        elif self.sym_table.get_variable_type(assign_stmt.lhs.lexeme)!= None:
            x = self.sym_table.get_variable_type(assign_stmt.lhs.lexeme)
            if assign_stmt.index_expr != None: #if there is an index expression, the type will be different
                 x = x[1:len(x)-1]
            if not (x == self.current_type):
                raise error.Error('already assigned '+ x + ' cannot be assigned '+ self.current_type+' ',assign_stmt.lhs.line,assign_stmt.lhs.column)
        self.current_type = None
                   
                                       
    def visit_simple_expr(self, simple_expr):
        self.current_type = simple_expr.term.tokentype
        if self.current_type == 'ID':
            if self.sym_table.get_variable_type(simple_expr.term.lexeme) == None:
                raise error.Error(simple_expr.term.lexeme + ' not yet defined ',simple_expr.term.line,simple_expr.term.column)
            else: #convert ID to actual token type
                self.current_type = self.sym_table.get_variable_type(simple_expr.term.lexeme)
        
          
    def visit_index_expr(self, index_expr):
        if self.sym_table.get_variable_type(index_expr.identifier.lexeme)== None:
             raise error.Error(index_expr.identifier.lexeme + ' not yet defined ',index_expr.identifier.line,index_expr.identifier.column)    
        index_expr.expr.accept(self)
        x = self.sym_table.get_variable_type(index_expr.identifier.lexeme)
        x = x[1:len(x)-1]
        self.current_type = x #if nested id expressions exist, this will be done multiple times
        
    def visit_list_expr(self, list_expr):
         for expr in list_expr.expressions:
            x=self.current_type
            if type(expr) == ast.SimpleExpr: # must look into other nodes to determine type of the expression
                term = expr.term
            if type(expr) == ast.ReadExpr: 
                term = expr.msg
            if type(expr) == ast.IndexExpr:
                term = expr.identifier
            expr.accept(self)
            if not(x == self.current_type or x==None or x[0]=='['):
                raise error.Error('expecting '+x+' found ' + self.current_type+' ',term.line,term.column)
         if self.current_type != None:
            self.current_type = '['+self.current_type+']'
            #print self.current_type #for testing
         else:
             self.current_type = '[]'
                 
    def visit_read_expr(self, read_expr):
        if read_expr.is_read_int :
            self.current_type = 'INT';
        else:
            self.current_type = 'STRING';
                   
    def visit_complex_expr(self, complex_expr):
        complex_expr.first_operand.accept(self)
        x = self.current_type 
        if self.current_type == 'BOOL':
            raise error.Error('cannot perform math operations on bools ',complex_expr.math_rel.line,complex_expr.math_rel.column)
        if complex_expr.math_rel.tokentype != 'PLUS':
            if self.current_type != 'INT': #strings, homogenous lists of any type, and integers can all be added.
                raise error.Error('can only do non-addition math operations on ints ',complex_expr.math_rel.line,complex_expr.math_rel.column)
        complex_expr.rest.accept(self)
        if type(complex_expr.rest) == ast.SimpleExpr: # must look into other nodes to determine type of the expression
            term = complex_expr.rest.term
        if type(complex_expr.rest) == ast.ReadExpr: 
            term = complex_expr.rest.msg
        if type(complex_expr.rest) == ast.IndexExpr:
            term = complex_expr.rest.identifier
        if type(complex_expr.rest) == ast.ListExpr:
            term = complex_expr.math_rel
        if not(x == self.current_type):
           if not(self.current_type[0] == '[' and x=='[]'):#all this is added to make sure an empty list 
             if not(self.current_type == '[]' and x[0]=='['):  #is added to another list
                raise error.Error('expecting '+x+' found ' + self.current_type+' ',term.line,term.column)#added to a list
        
        
